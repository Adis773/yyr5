
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://ztmzahzqhusoukcvtrmr.supabase.co';
const supabaseKey = 'sb_publishable_FYykrMMKbyLt2cF1TvWUeQ_TGFZHbSU';

export const supabase = createClient(supabaseUrl, supabaseKey);
