
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Camera, ChevronRight, Sparkles, Shield, Palette, Smartphone, 
  Globe, LogOut, Check, Bell, Database, Zap, User as UserIcon, Lock, 
  Eye, Monitor, Moon, Sun, Languages, Info, Mail, ShieldCheck
} from 'lucide-react';
import { User, AppTheme, Wallpaper } from '../../types';
import { WALLPAPERS } from '../../constants';

interface ProfileViewProps {
  user: User;
  onUpdateUser: (update: User | ((prev: User) => User)) => void;
  theme: AppTheme;
  onThemeChange: (theme: AppTheme) => void;
  wallpaper: Wallpaper;
  onWallpaperChange: (w: Wallpaper) => void;
  onLogout: () => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ user, onUpdateUser, theme, onThemeChange, wallpaper, onWallpaperChange, onLogout }) => {
  const [showWallpapers, setShowWallpapers] = useState(false);
  const [activeTab, setActiveTab] = useState<'account' | 'settings' | 'security'>('account');

  const isLight = theme === 'glass-light';
  const glassStyle = isLight ? 'bg-white border-gray-200' : 'glass border-white/5';
  const textPrimary = isLight ? 'text-gray-900' : 'text-white';
  const textSecondary = isLight ? 'text-gray-500' : 'text-gray-400';

  const toggleFaceId = () => {
    onUpdateUser(prev => ({
      ...prev,
      security: { ...prev.security, isFaceIdEnabled: !prev.security.isFaceIdEnabled }
    }));
  };

  const togglePasscode = () => {
    onUpdateUser(prev => ({
      ...prev,
      security: { ...prev.security, isPasscodeEnabled: !prev.security.isPasscodeEnabled, passcode: prev.security.passcode || '0000' }
    }));
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center pb-20">
      {/* Profile Header */}
      <div className="relative mb-8 mt-4">
        <div className="w-36 h-36 rounded-[2.8rem] p-1 bg-gradient-to-tr from-blue-500 via-purple-500 to-pink-500 shadow-2xl">
          <img src={user.avatar} className={`w-full h-full rounded-[2.6rem] object-cover border-4 ${isLight ? 'border-white' : 'border-[#0b0e14]'}`} alt="" />
        </div>
        <div className="absolute -bottom-2 -right-2 p-3 bg-blue-600 rounded-2xl shadow-xl border-4 border-[#0b0e14]">
          <Camera size={20} className="text-white" />
        </div>
      </div>
      
      <div className="flex items-center gap-2 mb-1">
        <h2 className={`text-3xl font-black ${textPrimary}`}>{user.username}</h2>
        {user.isVerified && <div className="p-1 bg-blue-500 rounded-full shadow-lg shadow-blue-500/20"><ShieldCheck size={16} className="text-white" /></div>}
      </div>
      <p className="text-blue-500 font-bold tracking-[0.2em] text-[10px] uppercase mb-8">Volna ID: {user.id}</p>

      {/* Tabs */}
      <div className={`w-full flex p-1 rounded-2xl mb-8 ${isLight ? 'bg-gray-200' : 'bg-white/5'}`}>
        {(['account', 'settings', 'security'] as const).map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 py-3 text-[10px] font-black uppercase tracking-widest rounded-xl transition-all ${
              activeTab === tab 
                ? 'bg-blue-600 text-white shadow-lg' 
                : `${textSecondary} hover:bg-white/5`
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'account' && (
          <motion.div key="account" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} className="w-full space-y-4">
            <div className={`p-6 rounded-[2.5rem] border ${glassStyle} space-y-6`}>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500"><UserIcon size={24} /></div>
                <div className="flex-1">
                  <span className={`text-[10px] uppercase font-black ${textSecondary}`}>Username</span>
                  <p className={`font-bold ${textPrimary}`}>{user.username}</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-500"><Mail size={24} /></div>
                <div className="flex-1">
                  <span className={`text-[10px] uppercase font-black ${textSecondary}`}>Email</span>
                  <p className={`font-bold ${textPrimary}`}>{user.email || 'Not verified'}</p>
                </div>
              </div>
            </div>
            <div className={`p-6 rounded-[2.5rem] border ${glassStyle} space-y-4`}>
              <button className="w-full flex items-center justify-between p-2 hover:bg-white/5 rounded-2xl transition-all">
                <div className="flex items-center gap-4">
                  <Monitor size={20} className="text-purple-500" />
                  <span className={`font-bold ${textPrimary}`}>My Activity</span>
                </div>
                <ChevronRight size={18} className={textSecondary} />
              </button>
              <button className="w-full flex items-center justify-between p-2 hover:bg-white/5 rounded-2xl transition-all">
                <div className="flex items-center gap-4">
                  <Info size={20} className="text-gray-400" />
                  <span className={`font-bold ${textPrimary}`}>Help & FAQ</span>
                </div>
                <ChevronRight size={18} className={textSecondary} />
              </button>
            </div>
          </motion.div>
        )}

        {activeTab === 'settings' && (
          <motion.div key="settings" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} className="w-full space-y-4">
             <div className={`p-6 rounded-[2.5rem] border ${glassStyle} space-y-6`}>
               <div className="flex items-center justify-between">
                 <div className="flex items-center gap-4">
                   <div className="w-11 h-11 rounded-2xl bg-orange-500/10 flex items-center justify-center text-orange-500"><Palette size={22} /></div>
                   <span className={`font-bold ${textPrimary}`}>Theme Mode</span>
                 </div>
                 <div className="flex gap-1 p-1 bg-black/5 rounded-xl">
                   <button onClick={() => onThemeChange('glass-light')} className={`p-2 rounded-lg ${isLight ? 'bg-white shadow-sm text-blue-600' : 'text-gray-500'}`}><Sun size={18} /></button>
                   <button onClick={() => onThemeChange('deep-dark')} className={`p-2 rounded-lg ${!isLight ? 'bg-blue-600 text-white shadow-sm' : 'text-gray-500'}`}><Moon size={18} /></button>
                 </div>
               </div>

               <button 
                 onClick={() => setShowWallpapers(true)}
                 className="w-full flex items-center justify-between group"
               >
                 <div className="flex items-center gap-4">
                   <div className="w-11 h-11 rounded-2xl bg-purple-500/10 flex items-center justify-center text-purple-500"><Smartphone size={22} /></div>
                   <div className="text-left">
                     <span className={`font-bold block ${textPrimary}`}>Wallpaper Engine</span>
                     <span className="text-[10px] text-gray-500 font-black uppercase">{wallpaper.label}</span>
                   </div>
                 </div>
                 <ChevronRight size={18} className={textSecondary} />
               </button>
             </div>
          </motion.div>
        )}

        {activeTab === 'security' && (
          <motion.div key="security" initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} className="w-full space-y-4">
             <div className={`p-6 rounded-[2.5rem] border ${glassStyle} space-y-6`}>
                <div className="flex items-center justify-between" onClick={toggleFaceId}>
                  <div className="flex items-center gap-4">
                    <div className="w-11 h-11 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500"><Shield size={22} /></div>
                    <div className="text-left">
                      <span className={`font-bold block ${textPrimary}`}>FaceID Authentication</span>
                    </div>
                  </div>
                  <div className={`w-12 h-7 rounded-full transition-all flex items-center px-1 ${user.security.isFaceIdEnabled ? 'bg-blue-600' : 'bg-gray-200'}`}>
                    <motion.div animate={{ x: user.security.isFaceIdEnabled ? 20 : 0 }} className="w-5 h-5 bg-white rounded-full shadow-md" />
                  </div>
                </div>

                <div className="flex items-center justify-between" onClick={togglePasscode}>
                  <div className="flex items-center gap-4">
                    <div className="w-11 h-11 rounded-2xl bg-orange-500/10 flex items-center justify-center text-orange-500"><Lock size={22} /></div>
                    <div className="text-left">
                      <span className={`font-bold block ${textPrimary}`}>Numeric Passcode</span>
                    </div>
                  </div>
                  <div className={`w-12 h-7 rounded-full transition-all flex items-center px-1 ${user.security.isPasscodeEnabled ? 'bg-blue-600' : 'bg-gray-200'}`}>
                    <motion.div animate={{ x: user.security.isPasscodeEnabled ? 20 : 0 }} className="w-5 h-5 bg-white rounded-full shadow-md" />
                  </div>
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button onClick={onLogout} className="w-full mt-10 flex items-center justify-center gap-4 p-6 glass rounded-[2.5rem] text-red-500 border border-red-500/10 active:scale-95 transition-all">
         <LogOut size={22} />
         <span className="font-black uppercase tracking-[0.2em]">Logout Account</span>
      </button>

      {/* Wallpaper Picker Overlay */}
      <AnimatePresence>
        {showWallpapers && (
          <>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[1000] bg-black/80 backdrop-blur-xl" onClick={() => setShowWallpapers(false)} />
            <motion.div 
              initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
              className="fixed bottom-0 left-0 right-0 h-[85vh] glass rounded-t-[3rem] z-[1001] border-t border-white/10 p-8 overflow-y-auto no-scrollbar"
            >
              <div className="flex justify-between items-center mb-8 sticky top-0 bg-transparent backdrop-blur-md pb-4 z-10">
                <h3 className="text-2xl font-black">Wallpapers</h3>
                <button onClick={() => setShowWallpapers(false)} className="p-2 glass rounded-full">✕</button>
              </div>

              {['Anime', 'Kung Fu', 'Sport', 'Gaming', 'Abstract'].map(cat => (
                <div key={cat} className="mb-10">
                  <h4 className="text-[10px] uppercase font-black tracking-widest text-blue-500 mb-4 px-1">{cat}</h4>
                  <div className="grid grid-cols-2 gap-4">
                    {WALLPAPERS.filter(w => w.category === (cat as any)).map(w => (
                      <button 
                        key={w.id} 
                        onClick={() => { onWallpaperChange(w); setShowWallpapers(false); }}
                        className="relative aspect-[3/4] rounded-3xl overflow-hidden group active:scale-95 transition-all shadow-lg"
                      >
                        <img src={w.url} className="w-full h-full object-cover transition-transform group-hover:scale-110" alt="" />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-4">
                          <span className="text-[11px] font-bold text-white mb-1">{w.label}</span>
                          {wallpaper.id === w.id && <Check className="text-blue-500" size={16} />}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default ProfileView;
