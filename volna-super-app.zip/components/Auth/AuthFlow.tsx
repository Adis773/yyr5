
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Key, User as UserIcon, ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface AuthFlowProps {
  onComplete: (user: any) => void;
}

const AuthFlow: React.FC<AuthFlowProps> = () => {
  const [step, setStep] = useState<'welcome' | 'login' | 'register' | 'check-email' | 'success'>('welcome');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setError(error.message);
      setLoading(false);
    } else {
      setStep('success');
    }
  };

  const handleRegister = async () => {
    setLoading(true);
    setError(null);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { username, avatar_url: `https://picsum.photos/seed/${username}/200` }
      }
    });

    if (error) {
      setError(error.message);
      setLoading(false);
    } else {
      if (data.session) {
        setStep('success');
      } else {
        setStep('check-email');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[500] bg-[#0b0e14] flex flex-col items-center justify-center p-8 text-white overflow-hidden">
      <AnimatePresence mode="wait">
        {step === 'welcome' && (
          <motion.div key="welcome" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.9 }} className="flex flex-col items-center text-center max-w-sm">
            <div className="w-24 h-24 wave-gradient rounded-[2.5rem] flex items-center justify-center shadow-2xl shadow-blue-500/50 mb-10">
              <Sparkles size={48} className="text-white fill-white" />
            </div>
            <h1 className="text-5xl font-black tracking-tighter mb-4">Volna App</h1>
            <p className="text-gray-400 font-medium mb-12">The ultra-secure super app. Real accounts, real privacy.</p>
            <div className="w-full space-y-4">
              <button onClick={() => setStep('login')} className="w-full py-5 wave-gradient rounded-3xl font-black uppercase tracking-[0.2em] shadow-lg shadow-blue-500/20 active:scale-95 transition-all">Sign In</button>
              <button onClick={() => setStep('register')} className="w-full py-5 glass rounded-3xl font-black uppercase tracking-[0.2em] active:scale-95 transition-all text-gray-400">Create Account</button>
            </div>
          </motion.div>
        )}

        {(step === 'login' || step === 'register') && (
          <motion.div key="auth-form" initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} className="w-full max-w-sm space-y-8">
            <button onClick={() => setStep('welcome')} className="text-blue-500 font-black uppercase tracking-widest text-[10px]">Back</button>
            <h2 className="text-3xl font-black">{step === 'login' ? 'Welcome Back' : 'Join Network'}</h2>
            
            <div className="space-y-4">
              {step === 'register' && (
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black text-gray-500 ml-2">Username</label>
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                    <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} placeholder="@username" className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 outline-none focus:border-blue-500 transition-all" />
                  </div>
                </div>
              )}
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black text-gray-500 ml-2">Email</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@address.com" className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 outline-none focus:border-blue-500 transition-all" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-black text-gray-500 ml-2">Password</label>
                <div className="relative">
                  <Key className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" size={18} />
                  <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 pl-12 outline-none focus:border-blue-500 transition-all" />
                </div>
              </div>
            </div>

            {error && <p className="text-red-500 text-xs font-bold text-center uppercase tracking-widest">{error}</p>}

            <button disabled={loading} onClick={step === 'login' ? handleLogin : handleRegister} className="w-full py-5 wave-gradient rounded-3xl font-black uppercase tracking-[0.2em] shadow-lg shadow-blue-500/20 active:scale-95 transition-all flex items-center justify-center gap-2">
              {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : step === 'login' ? 'Login' : 'Register'}
            </button>
          </motion.div>
        )}

        {step === 'check-email' && (
          <motion.div key="check-email" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center text-center max-w-sm">
            <div className="w-20 h-20 bg-blue-500/20 rounded-full flex items-center justify-center mb-8 text-blue-500">
              <Mail size={40} />
            </div>
            <h2 className="text-3xl font-black mb-4">Check your Email</h2>
            <p className="text-gray-500 mb-8">We sent a verification link to <b>{email}</b>. Click the link to activate your Volna account.</p>
            <button onClick={() => setStep('login')} className="text-blue-500 font-black uppercase tracking-widest text-xs">I've verified my email</button>
          </motion.div>
        )}

        {step === 'success' && (
          <motion.div key="success" initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="flex flex-col items-center text-center">
            <div className="w-24 h-24 bg-emerald-500 rounded-full flex items-center justify-center mb-6 shadow-2xl shadow-emerald-500/40">
              <CheckCircle2 size={48} className="text-white" />
            </div>
            <h2 className="text-3xl font-black mb-2">Authenticated</h2>
            <p className="text-gray-500">Welcome back to the Network.</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AuthFlow;
