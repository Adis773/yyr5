
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, X, Brain, Zap, Languages, Search, Mic } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

const AISmartAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [isThinking, setIsThinking] = useState(false);

  const handleAIQuery = async () => {
    if (!query.trim()) return;
    
    setIsThinking(true);
    setResult(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `You are the Volna Super-App Assistant. Help the user with their query: ${query}. Keep the answer brief and professional.`,
        config: {
          thinkingConfig: { thinkingBudget: 0 }
        }
      });
      setResult(response.text || "I couldn't generate a response.");
    } catch (err) {
      console.error(err);
      setResult("Error connecting to Volna AI. Check your connection.");
    } finally {
      setIsThinking(false);
    }
  };

  return (
    <>
      <motion.button
        onClick={() => setIsOpen(true)}
        whileHover={{ scale: 1.1, rotate: 5 }}
        whileTap={{ scale: 0.9 }}
        className="fixed bottom-32 right-6 w-14 h-14 wave-gradient rounded-full flex items-center justify-center shadow-2xl shadow-blue-500/50 z-40 border-2 border-white/20"
      >
        <Sparkles className="text-white fill-white" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/40 backdrop-blur-md z-[200]"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="fixed bottom-32 right-6 left-6 max-w-md mx-auto glass rounded-[32px] p-6 z-[210] border border-white/10 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-blue-500/20 rounded-xl text-blue-400">
                    <Brain size={20} />
                  </div>
                  <h3 className="font-black text-lg tracking-tight">Volna AI</h3>
                </div>
                <button onClick={() => setIsOpen(false)} className="p-2 glass rounded-full">
                  <X size={18} />
                </button>
              </div>

              <div className="space-y-4">
                <div className="flex gap-2 overflow-x-auto no-scrollbar py-1">
                  {['Summarize Chat', 'AI Translation', 'Video Keywords', 'Fact Check'].map(tag => (
                    <button key={tag} className="px-3 py-1.5 glass rounded-xl text-[10px] font-bold uppercase tracking-wider text-gray-400 whitespace-nowrap border border-white/5">
                      {tag}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <textarea 
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Ask Volna AI anything..."
                    className="w-full bg-white/5 rounded-2xl p-4 pr-12 outline-none border border-white/5 min-h-[100px] text-sm resize-none"
                  />
                  <button 
                    onClick={handleAIQuery}
                    className="absolute bottom-4 right-4 p-2 wave-gradient rounded-xl text-white shadow-lg shadow-blue-500/20"
                  >
                    {isThinking ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <Zap size={18} />
                    )}
                  </button>
                </div>

                <AnimatePresence>
                  {result && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="p-4 bg-blue-500/10 rounded-2xl border border-blue-500/20"
                    >
                      <p className="text-sm leading-relaxed text-blue-100">{result}</p>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="flex items-center justify-between text-[10px] text-gray-500 font-bold uppercase tracking-widest px-1">
                  <div className="flex items-center gap-1.5">
                    <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                    AI Core v2.5 Online
                  </div>
                  <span>Powered by Gemini</span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default AISmartAssistant;
