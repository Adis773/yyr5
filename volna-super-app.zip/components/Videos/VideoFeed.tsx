
import React from 'react';
import { motion } from 'framer-motion';
import { Video as VideoData } from '../../types';
import { MoreVertical, Heart, MessageSquare, Share2, Play } from 'lucide-react';

interface VideoFeedProps {
  videos: VideoData[];
}

const VideoFeed: React.FC<VideoFeedProps> = ({ videos }) => {
  const categories = ['For You', 'Shorts', 'Gaming', 'Music', 'Live', 'Podcasts', 'Tech'];

  return (
    <div className="space-y-6 pt-4">
      <div className="flex gap-3 overflow-x-auto px-6 py-2 no-scrollbar">
        {categories.map((cat, i) => (
          <button 
            key={cat} 
            className={`px-6 py-2.5 rounded-2xl text-[13px] font-black tracking-wider uppercase transition-all shadow-lg ${
              i === 0 ? 'wave-gradient text-white shadow-blue-500/20' : 'glass text-gray-400 hover:bg-white/10'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="px-6 space-y-10">
        {videos.map((video, idx) => (
          <motion.div 
            key={video.id}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="group"
          >
            <div className="relative aspect-[16/10] rounded-[2.5rem] overflow-hidden mb-5 shadow-2xl shadow-black ring-1 ring-white/10">
              <img src={video.thumbnail} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out" alt={video.title} />
              
              <div className="absolute top-4 right-4 px-3 py-1.5 glass rounded-xl text-[11px] font-black tracking-widest bg-black/40">
                {video.duration}
              </div>

              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
                 <motion.button 
                   whileHover={{ scale: 1.1 }}
                   whileTap={{ scale: 0.9 }}
                   className="w-20 h-20 rounded-full wave-gradient flex items-center justify-center text-white shadow-2xl shadow-blue-500/50 pl-2"
                 >
                   <Play size={36} fill="currentColor" />
                 </motion.button>
              </div>

              <div className="absolute bottom-4 left-4 flex gap-2">
                 <div className="glass px-3 py-1.5 rounded-xl text-[10px] font-black uppercase text-white flex items-center gap-2">
                    <Heart size={14} className="text-red-500 fill-red-500" /> 12K
                 </div>
                 <div className="glass px-3 py-1.5 rounded-xl text-[10px] font-black uppercase text-white flex items-center gap-2">
                    <MessageSquare size={14} className="text-blue-400" /> 452
                 </div>
              </div>
            </div>
            
            <div className="flex gap-4 px-1">
              <img src={video.authorAvatar} className="w-12 h-12 rounded-[1.2rem] object-cover border-2 border-white/5 shadow-lg" alt={video.author} />
              <div className="flex-1 min-w-0">
                <h3 className="font-black text-lg leading-tight mb-1 line-clamp-2 group-hover:text-blue-400 transition-colors">{video.title}</h3>
                <div className="flex items-center gap-2 text-[11px] text-gray-500 font-bold uppercase tracking-wider">
                  <span className="text-white">{video.author}</span>
                  <span>•</span>
                  <span>{video.views} views</span>
                  <span>•</span>
                  <span>{video.time}</span>
                </div>
              </div>
              <button className="p-3 h-fit rounded-2xl glass hover:bg-white/10 active:scale-90 transition-all">
                <MoreVertical size={20} className="text-gray-400" />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default VideoFeed;
