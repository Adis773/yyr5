
import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PhoneOff, Mic, MicOff, Video, VideoOff, Volume2, Maximize2, X } from 'lucide-react';
import { Chat } from '../../types';

interface VideoCallOverlayProps {
  callType: 'audio' | 'video';
  chat: Chat;
  onClose: () => void;
}

const VideoCallOverlay: React.FC<VideoCallOverlayProps> = ({ callType, chat, onClose }) => {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(callType === 'audio');
  const [callDuration, setCallDuration] = useState(0);

  useEffect(() => {
    let interval: any;
    if (callDuration >= 0) {
      interval = setInterval(() => setCallDuration(d => d + 1), 1000);
    }

    if (callType === 'video' || !isVideoOff) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: true })
        .then(stream => {
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream;
          }
        })
        .catch(err => console.error("Camera access denied", err));
    }

    return () => {
      clearInterval(interval);
      if (localVideoRef.current && localVideoRef.current.srcObject) {
        const stream = localVideoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 1.1 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 z-[1000] bg-[#0b0e14] flex flex-col items-center justify-center p-6"
    >
      {/* Background/Remote Video Mock */}
      <div className="absolute inset-0 z-0">
        {callType === 'video' && !isVideoOff ? (
          <div className="w-full h-full bg-black flex items-center justify-center">
            <img src={chat.avatar} className="w-full h-full object-cover blur-2xl opacity-30" alt="" />
            <div className="absolute inset-0 flex flex-col items-center justify-center">
               <motion.img 
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ repeat: Infinity, duration: 4 }}
                src={chat.avatar} className="w-48 h-48 rounded-[3rem] object-cover shadow-2xl border-4 border-white/10" alt={chat.name} 
               />
               <h2 className="text-3xl font-black mt-8">{chat.name}</h2>
               <p className="text-blue-400 font-bold uppercase tracking-widest mt-2">Connecting...</p>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full gap-8">
             <div className="relative">
                <motion.div 
                  animate={{ scale: [1, 1.5, 1], opacity: [0.3, 0.1, 0.3] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="absolute inset-0 bg-blue-500 rounded-full blur-3xl"
                />
                <img src={chat.avatar} className="w-48 h-48 rounded-full object-cover relative z-10 border-8 border-white/5" alt={chat.name} />
             </div>
             <div className="text-center z-10">
               <h2 className="text-4xl font-black tracking-tight mb-2">{chat.name}</h2>
               <p className="text-gray-400 font-medium text-lg">{formatTime(callDuration)}</p>
             </div>
          </div>
        )}
      </div>

      {/* Local Preview */}
      <motion.div 
        drag
        dragConstraints={{ left: -100, right: 100, top: -200, bottom: 200 }}
        className="absolute top-16 right-6 w-32 h-48 bg-black/40 backdrop-blur-xl rounded-[2rem] overflow-hidden border border-white/20 z-20 shadow-2xl"
      >
        <video 
          ref={localVideoRef} 
          autoPlay 
          muted 
          playsInline 
          className={`w-full h-full object-cover ${isVideoOff ? 'hidden' : 'block'}`} 
        />
        {isVideoOff && <div className="w-full h-full flex items-center justify-center text-gray-500"><User size={24} /></div>}
      </motion.div>

      {/* Controls */}
      <div className="mt-auto mb-12 flex items-center gap-6 z-10">
        <button 
          onClick={() => setIsMuted(!isMuted)}
          className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${isMuted ? 'bg-red-500/20 text-red-500' : 'glass'}`}
        >
          {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
        </button>
        <button 
          onClick={onClose}
          className="w-20 h-20 bg-red-600 rounded-[2rem] flex items-center justify-center text-white shadow-2xl shadow-red-500/50 hover:scale-110 active:scale-90 transition-all"
        >
          <PhoneOff size={32} />
        </button>
        <button 
          onClick={() => setIsVideoOff(!isVideoOff)}
          className={`w-16 h-16 rounded-full flex items-center justify-center transition-all ${isVideoOff ? 'bg-white/10 text-gray-400' : 'glass'}`}
        >
          {isVideoOff ? <VideoOff size={24} /> : <Video size={24} />}
        </button>
      </div>

      <button className="absolute top-14 left-6 p-3 glass rounded-2xl z-10" onClick={onClose}>
        <Maximize2 size={20} />
      </button>
    </motion.div>
  );
};

const User = ({ size }: { size: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
  </svg>
);

export default VideoCallOverlay;
