
import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Send, Mic, Paperclip, Phone, Video as VideoIcon, CheckCheck, Play } from 'lucide-react';
import { Chat, User, Message, Wallpaper, AppTheme } from '../../types';

interface ChatViewProps {
  chat: Chat;
  myUser: User;
  onClose: () => void;
  onSendMessage: (msg: Partial<Message>) => void;
  onStartCall: (type: 'audio' | 'video') => void;
  wallpaper: Wallpaper;
  theme: AppTheme;
}

const ChatView: React.FC<ChatViewProps> = ({ chat, myUser, onClose, onSendMessage, onStartCall, wallpaper, theme }) => {
  const [inputText, setInputText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const isLight = theme === 'glass-light';

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [chat.messages]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    onSendMessage({ text: inputText, type: 'text' });
    setInputText('');
  };

  return (
    <motion.div
      initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 30, stiffness: 250 }}
      className={`fixed inset-0 z-[150] flex flex-col ${isLight ? 'bg-white' : 'bg-black'}`}
    >
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {isLight ? (
          <div className="absolute inset-0 bg-blue-50/50" />
        ) : (
          <img src={wallpaper.url} className="w-full h-full object-cover opacity-20 blur-xl scale-110" alt="" />
        )}
      </div>

      <div className={`px-6 pt-14 pb-4 flex items-center gap-4 border-b z-20 ${isLight ? 'bg-white/80 border-gray-100' : 'glass border-white/5'}`}>
        <button onClick={onClose} className={`p-3 -ml-2 rounded-2xl ${isLight ? 'bg-gray-100' : 'glass'}`}><ArrowLeft size={24} /></button>
        <div className="flex-1 flex items-center gap-3">
          <img src={chat.avatar} className="w-11 h-11 rounded-2xl object-cover" alt="" />
          <div className="min-w-0">
            <h3 className={`font-bold truncate ${isLight ? 'text-gray-900' : 'text-white'}`}>{chat.name}</h3>
            <span className="text-[10px] text-blue-500 font-black uppercase">Secured Session</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => onStartCall('audio')} className={`p-3 rounded-2xl text-blue-500 ${isLight ? 'bg-blue-50' : 'glass'}`}><Phone size={22} /></button>
          <button onClick={() => onStartCall('video')} className={`p-3 rounded-2xl text-blue-500 ${isLight ? 'bg-blue-50' : 'glass'}`}><VideoIcon size={22} /></button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar z-10">
        {chat.messages.map((m, idx) => {
          const isMe = m.senderId === myUser.id;
          return (
            <motion.div 
              key={m.id} 
              initial={{ opacity: 0, y: 15, scale: 0.8, x: isMe ? 20 : -20 }} 
              animate={{ opacity: 1, y: 0, scale: 1, x: 0 }}
              transition={{ type: 'spring', bounce: 0.4 }}
              className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[85%] px-5 py-3 rounded-[1.8rem] relative shadow-lg ${
                isMe ? 'wave-gradient rounded-tr-none text-white' : `${isLight ? 'bg-gray-100 text-gray-800' : 'glass text-gray-100'} rounded-tl-none`
              }`}>
                {m.type === 'voice' ? <div className="flex items-center gap-3 min-w-[150px]"><Play size={18} fill="currentColor" /> <div className="flex-1 h-1 bg-white/30 rounded-full" /></div> : <p className="text-[15px] font-medium leading-relaxed">{m.text}</p>}
                <div className={`flex items-center justify-end gap-1.5 mt-1 opacity-60 text-[9px] font-bold ${isMe ? 'text-white/80' : ''}`}>
                  12:30 {isMe && <CheckCheck size={12} />}
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="p-6 pb-12 z-20">
        <div className={`px-4 py-2 rounded-[2.2rem] border flex items-center gap-3 shadow-xl ${isLight ? 'bg-white border-gray-200' : 'glass border-white/10'}`}>
          <button className="p-2 text-gray-400 hover:text-blue-500"><Paperclip size={22} /></button>
          <input 
            type="text" value={inputText} onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Secure Message..." className={`w-full bg-transparent outline-none py-3 text-[16px] ${isLight ? 'text-gray-900' : 'text-white'}`}
          />
          <motion.button 
            whileTap={{ scale: 0.9 }} onClick={handleSend}
            className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all ${inputText ? 'wave-gradient text-white' : isLight ? 'bg-gray-100 text-blue-500' : 'glass text-blue-400'}`}
          >
            {inputText ? <Send size={20} /> : <Mic size={20} />}
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
};

export default ChatView;
