
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, Smartphone, Key, Lock, User, RefreshCw } from 'lucide-react';
import { SecurityConfig } from '../../types';

interface SecurityOverlayProps {
  config: SecurityConfig;
  onUnlock: () => void;
}

const SecurityOverlay: React.FC<SecurityOverlayProps> = ({ config, onUnlock }) => {
  const [passcode, setPasscode] = useState<string[]>([]);
  const [isScanning, setIsScanning] = useState(config.isFaceIdEnabled);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let stream: MediaStream | null = null;
    if (isScanning) {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(s => {
          stream = s;
          if (videoRef.current) {
            videoRef.current.srcObject = s;
          }
          // Simulate successful scan
          setTimeout(() => {
            onUnlock();
          }, 3500);
        })
        .catch(err => {
          console.error(err);
          setError("Camera access required for FaceID.");
          setIsScanning(false);
        });
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [isScanning]);

  const handleKeypad = (num: string) => {
    if (passcode.length < 4) {
      const newPass = [...passcode, num];
      setPasscode(newPass);
      if (newPass.length === 4) {
        // Simple mock check
        if (config.passcode === newPass.join('') || !config.passcode) {
          setTimeout(onUnlock, 300);
        } else {
          setPasscode([]);
          if (window.navigator.vibrate) window.navigator.vibrate([100, 50, 100]);
        }
      }
    }
    if (window.navigator.vibrate) window.navigator.vibrate(15);
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-[#0b0e14] flex flex-col items-center justify-center text-white overflow-hidden">
      <AnimatePresence mode="wait">
        {isScanning ? (
          <motion.div 
            key="scanning"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="relative w-full h-full flex flex-col items-center justify-center"
          >
            {/* Real Camera Feed */}
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              muted 
              className="absolute inset-0 w-full h-full object-cover blur-md opacity-40 grayscale"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-blue-500/10 via-transparent to-black" />

            <div className="relative w-56 h-56 mb-12 flex items-center justify-center">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                className="absolute inset-0 border-2 border-dashed border-blue-500/40 rounded-full"
              />
              <div className="w-40 h-40 rounded-full border-2 border-white/10 flex items-center justify-center overflow-hidden">
                <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover scale-150" />
              </div>
              <motion.div 
                animate={{ y: [-100, 100, -100] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute w-64 h-0.5 bg-blue-400 shadow-[0_0_20px_rgba(59,130,246,1)] z-20"
              />
            </div>
            
            <h2 className="text-2xl font-black tracking-tighter mb-2 z-10">Securing Access</h2>
            <p className="text-blue-400 font-bold uppercase tracking-[0.4em] text-[10px] animate-pulse z-10">Analyzing FaceID Patterns...</p>
            
            <button 
              onClick={() => setIsScanning(false)}
              className="mt-12 text-gray-500 font-black uppercase text-[10px] tracking-widest hover:text-white transition-colors z-10"
            >
              Use Passcode instead
            </button>
          </motion.div>
        ) : (
          <motion.div 
            key="passcode"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center w-full max-w-xs"
          >
            <Lock className="text-blue-500 mb-8" size={32} />
            <h2 className="text-xl font-black mb-10">Volna Secured</h2>
            
            <div className="flex gap-6 mb-16">
              {[0, 1, 2, 3].map(i => (
                <div key={i} className={`w-4 h-4 rounded-full border-2 border-blue-500 transition-all ${passcode.length > i ? 'bg-blue-500 shadow-[0_0_12px_rgba(59,130,246,0.7)]' : ''}`} />
              ))}
            </div>

            <div className="grid grid-cols-3 gap-6 w-full">
              {['1','2','3','4','5','6','7','8','9','','0','C'].map((val, i) => (
                <button 
                  key={i}
                  disabled={!val}
                  onClick={() => val === 'C' ? setPasscode([]) : handleKeypad(val)}
                  className={`w-16 h-16 rounded-full glass flex items-center justify-center text-xl font-bold active:scale-90 active:bg-blue-600/20 transition-all ${!val ? 'invisible' : ''}`}
                >
                  {val === 'C' ? <RefreshCw size={20} /> : val}
                </button>
              ))}
            </div>
            
            {config.isFaceIdEnabled && (
              <button 
                onClick={() => setIsScanning(true)}
                className="mt-12 text-blue-500 font-black uppercase text-[10px] tracking-widest hover:brightness-125"
              >
                Retry FaceID
              </button>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SecurityOverlay;
