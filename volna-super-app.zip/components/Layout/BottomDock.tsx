
import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, PlayCircle, Plus, Bell, User } from 'lucide-react';
import { TabType, AppTheme } from '../../types';

interface BottomDockProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  onCreateClick: () => void;
  theme: AppTheme;
}

const BottomDock: React.FC<BottomDockProps> = ({ activeTab, onTabChange, onCreateClick, theme }) => {
  const isLight = theme === 'glass-light';
  const tabs: { id: TabType; icon: React.ReactNode; label: string }[] = [
    { id: 'chats', icon: <MessageCircle size={26} />, label: 'Chat' },
    { id: 'videos', icon: <PlayCircle size={26} />, label: 'Video' },
    { id: 'create', icon: <Plus size={36} />, label: 'New' },
    { id: 'notifications', icon: <Bell size={26} />, label: 'Inbox' },
    { id: 'profile', icon: <User size={26} />, label: 'Me' },
  ];

  return (
    <div className="fixed bottom-10 left-1/2 -translate-x-1/2 w-[94%] max-w-xl z-[100]">
      <div className={`${isLight ? 'bg-white/80 border-gray-200 shadow-xl' : 'bg-white/[0.02] border-white/10 shadow-[0_40px_80px_-20px_rgba(0,0,0,1)]'} backdrop-blur-[45px] px-6 py-5 rounded-[3rem] border flex items-center justify-between ring-1 ring-white/10`}>
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <motion.button
              key={tab.id}
              onClick={() => tab.id === 'create' ? onCreateClick() : onTabChange(tab.id)}
              whileHover={{ scale: 1.3, y: -8 }}
              whileTap={{ scale: 0.8 }}
              animate={{ 
                scale: isActive && tab.id !== 'create' ? 1.4 : 1,
                y: isActive && tab.id !== 'create' ? -4 : 0 
              }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              className={`flex flex-col items-center gap-1.5 transition-all relative ${
                isActive ? 'text-blue-500' : isLight ? 'text-gray-400' : 'text-gray-500'
              } ${tab.id === 'create' ? 'text-white' : ''}`}
            >
              {tab.id === 'create' ? (
                <div className={`w-16 h-16 -mt-16 rounded-[2.2rem] wave-gradient flex items-center justify-center shadow-2xl border-[6px] hover:rotate-180 transition-all duration-700 ${isLight ? 'border-white' : 'border-[#0b0e14]'}`}>
                  {tab.icon}
                </div>
              ) : (
                <div className={`p-2 rounded-2xl transition-all ${isActive ? 'bg-blue-500/15 shadow-[0_0_20px_rgba(59,130,246,0.3)]' : ''}`}>
                  {React.cloneElement(tab.icon as React.ReactElement, { strokeWidth: isActive ? 3 : 2 })}
                </div>
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
};

export default BottomDock;
