
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, MessageCircle, Users, Radio, Video as Vid, Play, Image, UserPlus, CheckCircle2 } from 'lucide-react';

interface CreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddContact: (id: string, name: string) => void;
}

const CreateModal: React.FC<CreateModalProps> = ({ isOpen, onClose, onAddContact }) => {
  const [view, setView] = useState<'menu' | 'add-contact' | 'upload-progress'>('menu');
  const [contactId, setContactId] = useState('');
  const [contactName, setContactName] = useState('');
  const [uploadStatus, setUploadStatus] = useState(0);

  const options = [
    { id: 'add-contact', icon: <UserPlus />, label: 'Add Contact', color: 'bg-emerald-500' },
    { id: 'group', icon: <Users />, label: 'New Group', color: 'bg-purple-500' },
    { id: 'channel', icon: <Radio />, label: 'Channel', color: 'bg-orange-500' },
    { id: 'video', icon: <Play />, label: 'Upload Video', color: 'bg-red-500' },
    { id: 'shorts', icon: <Vid />, label: 'Shorts', color: 'bg-pink-500' },
    { id: 'story', icon: <Image />, label: 'Add Story', color: 'bg-cyan-500' },
  ];

  const handleOptionClick = (id: string) => {
    if (id === 'add-contact') setView('add-contact');
    else if (['video', 'shorts', 'story'].includes(id)) {
      setView('upload-progress');
      startUploadSim();
    }
  };

  const startUploadSim = () => {
    setUploadStatus(0);
    const interval = setInterval(() => {
      setUploadStatus(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            onClose();
            setView('menu');
          }, 1500);
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  return (
    <AnimatePresence onExitComplete={() => setView('menu')}>
      {isOpen && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} className="fixed inset-0 bg-black/70 backdrop-blur-xl z-[110]" />
          <motion.div
            initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed bottom-0 left-0 right-0 glass rounded-t-[3rem] p-8 pb-14 z-[120] border-t border-white/10"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-black">{view === 'menu' ? 'Create New' : view === 'add-contact' ? 'Add Contact' : 'Uploading...'}</h2>
              <button onClick={() => view === 'menu' ? onClose() : setView('menu')} className="p-2 glass rounded-full hover:bg-white/10">
                <X size={20} />
              </button>
            </div>

            {view === 'menu' && (
              <div className="grid grid-cols-3 gap-8">
                {options.map((opt) => (
                  <button key={opt.id} onClick={() => handleOptionClick(opt.id)} className="flex flex-col items-center gap-3 active:scale-90 transition-all group">
                    <div className={`w-20 h-20 rounded-[2rem] ${opt.color} flex items-center justify-center text-white shadow-xl shadow-${opt.color.split('-')[1]}-500/20 group-hover:scale-110 transition-transform`}>
                      {React.cloneElement(opt.icon as React.ReactElement, { size: 32 })}
                    </div>
                    <span className="text-[11px] font-black uppercase tracking-widest text-gray-400 group-hover:text-white">{opt.label}</span>
                  </button>
                ))}
              </div>
            )}

            {view === 'add-contact' && (
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black text-gray-500 ml-2">Unique ID (e.g. 123456)</label>
                  <input 
                    type="text" value={contactId} onChange={(e) => setContactId(e.target.value)}
                    placeholder="Enter Volna ID" className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 outline-none focus:border-blue-500 transition-colors"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] uppercase font-black text-gray-500 ml-2">Contact Name</label>
                  <input 
                    type="text" value={contactName} onChange={(e) => setContactName(e.target.value)}
                    placeholder="Enter name" className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 outline-none focus:border-blue-500 transition-colors"
                  />
                </div>
                <button 
                  onClick={() => onAddContact(contactId, contactName)}
                  className="w-full py-4 wave-gradient rounded-2xl font-black uppercase tracking-[0.2em] shadow-lg shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50"
                  disabled={!contactId || !contactName}
                >
                  Add Contact
                </button>
              </div>
            )}

            {view === 'upload-progress' && (
              <div className="py-10 text-center space-y-8">
                <div className="relative w-32 h-32 mx-auto">
                   <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="6" fill="transparent" className="text-white/5" />
                      <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="6" fill="transparent" 
                        className="text-blue-500 transition-all duration-300" 
                        strokeDasharray={283} 
                        strokeDashoffset={283 - (283 * uploadStatus) / 100}
                        strokeLinecap="round"
                      />
                   </svg>
                   <div className="absolute inset-0 flex items-center justify-center font-black text-xl">
                      {uploadStatus === 100 ? <CheckCircle2 size={40} className="text-green-500" /> : `${uploadStatus}%`}
                   </div>
                </div>
                <p className="text-gray-400 font-bold tracking-widest uppercase text-sm">
                  {uploadStatus === 100 ? 'Successfully Uploaded!' : 'Processing AI Metadata...'}
                </p>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CreateModal;
